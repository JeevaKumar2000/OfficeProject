/**
 * 
 * @param {Request} request 
 * @param {object} promptProperty 
 * @returns 
 */
const fulfillment = require('../utils/utils.js')

async function CP1500_EligibilityPrompts(request, promptProperty, tag) {

    let text = '';
    let parameters = {};
    let jsonResponse = {};
    jsonResponse.sessionInfo = request.body.sessionInfo;
    let fulfillment_response = fulfillment.fulfillment_response();
    jsonResponse.fulfillment_response = fulfillment_response;

    try {
        if ('parameters' in (request.body.sessionInfo)) {
            parameters = request.body.sessionInfo.parameters;
        }
        console.log('Parameter value till before scenarios : ', parameters);

        if(parameters.memberEligibilityResponse.eligibleFlag === 'true'){
            text = promptProperty.CommercialProvider_CP1507_Prmt_MemberEligible + ' ' + parameters.memberEligibilityResponse.memberName + ' ' + promptProperty.CommercialProvider_CP1507_Prmt_MemberEligible2 + ' ' + parameters.dateOfBirth + ' ' + promptProperty.CommercialProvider_CP1507_Prmt_MemberEligibleYes3 + ' ' + parameters.dateOfService;
        }else{
            text = promptProperty.CommercialProvider_CP1507_Prmt_MemberEligible + ' ' + parameters.memberEligibilityResponse.memberName + ' ' + promptProperty.CommercialProvider_CP1507_Prmt_MemberEligible2 + ' ' + parameters.dateOfBirth + ' ' + promptProperty.CommercialProvider_CP1507_Prmt_MemberEligibleNo3 + ' ' + parameters.dateOfService;
        }

        if(parameters.memberEligibilityResponse.planNetworkName != "" ){
           text = text + promptProperty.CommercialProvider_CP1507_Prmt_PlanName + ' ' + parameters.memberEligibilityResponse.planNetworkName + ' ' + parameters.memberEligibilityResponse.planNetworkName + ' ' +promptProperty.CommercialProvider_CP1507_Prmt_PlanName2;
        }

        if(parameters.memberEligibilityResponse.planNetworkDesc != "" ){
            text = text + promptProperty.CommercialProvider_CP1507_Prmt_PlanDesc + ' ' + parameters.memberEligibilityResponse.planNetworkDesc;
        }

        if(parameters.memberEligibilityResponse.haCopayReturn != "" ){
            text = text + promptProperty.CommercialProvider_CP1507_Prmt_CoPayReturn + ' ' + parameters.memberEligibilityResponse.haCopayReturn;
        }

        


      

    } catch (e) {
        console.error(e.message);
    }
    console.log('text : ', text);
    jsonResponse.fulfillment_response.messages[0].text.text[0] = text;
    return jsonResponse;

}

function equalsIgnoreCase(tag, key) {
    return tag.toLowerCase() === key.toLowerCase();
}

module.exports = { CP1500_EligibilityPrompts };