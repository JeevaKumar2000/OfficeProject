/**
 * 
 * @param {Request} request 
 * @param {object} promptProperty 
 * @returns 
 */
const fulfillment = require('../utils/utils.js')

async function CP1500_Prompts(request, promptProperty, tag) {

    let text = '';
    let parameters = {};
    let jsonResponse = {};
    jsonResponse.sessionInfo = request.body.sessionInfo;
    let fulfillment_response = fulfillment.fulfillment_response();
    jsonResponse.fulfillment_response = fulfillment_response;

    try {
        if ('parameters' in (request.body.sessionInfo)) {
            parameters = request.body.sessionInfo.parameters;
        }

        if (equalsIgnoreCase(tag, 'CommercialProvider_CP1500_Prmt_Acknowledgement')) {
            //text = promptProperty.CommercialProvider_CP1500_Prmt_Acknowledgement + ' ' + parameters.intentName + ' ' '<speak> ${promptProperty.CommercialProvider_CP1500_Prmt_Acknowledgement} ${parameters.intentName} <break time='4s'/> </speak>';
            text = `<speak> ${promptProperty.CommercialProvider_CP1500_Prmt_Acknowledgement} ${parameters.intentName} <break time='2s'/> </speak>` ;
        } else if (equalsIgnoreCase(tag, 'CommercialProvider_CP1505_Prmt_Avality')){
            text = promptProperty.CommercialProvider_CP1505_Prmt_Avality;
        } else if (equalsIgnoreCase(tag, 'CommercialProvider_CP1507_Prmt_MemberEligible')){
            text = promptProperty.CommercialProvider_CP1507_Prmt_MemberEligible;
        } else if (equalsIgnoreCase(tag, 'CommercialProvider_CP1507_Prmt_NotMemberEligible')){
            text = promptProperty.CommercialProvider_CP1507_Prmt_NotMemberEligible;
        } else if (equalsIgnoreCase(tag, 'CommercialProvider_CP1507_Prmt_PlanDesc')){
            text = promptProperty.CommercialProvider_CP1507_Prmt_PlanDesc;
        } else if (equalsIgnoreCase(tag, 'CommercialProvider_CP1507_Prmt_CoPayReturn')){
            text = promptProperty.CommercialProvider_CP1507_Prmt_CoPayReturn;
        } else if (equalsIgnoreCase(tag, 'CommercialProvider_CP1511_Prmt_ClaimNotify')){
            text = promptProperty.CommercialProvider_CP1511_Prmt_ClaimNotify;
        } else if (equalsIgnoreCase(tag, 'CommercialProvider_CP1512_Prmt_LookupResponse')){
            text = promptProperty.CommercialProvider_CP1512_Prmt_LookupResponse;
        } else if (equalsIgnoreCase(tag, 'CommercialProvider_CP1512_Prmt_LookupResponseLT')){
            text = promptProperty.CommercialProvider_CP1512_Prmt_LookupResponseLT;
        } else if (equalsIgnoreCase(tag, 'CommercialProvider_CP1512_Prmt_LookupResponseGT')){
            text = promptProperty.CommercialProvider_CP1512_Prmt_LookupResponseGT;
        } else if (equalsIgnoreCase(tag, 'CommercialProvider_CP1523_Prmt_ClaimLookup')){
            text = promptProperty.CommercialProvider_CP1523_Prmt_ClaimLookup;
        } else if (equalsIgnoreCase(tag, 'CommercialProvider_CP1501_Prmt_SingleClaim')){
            text = promptProperty.CommercialProvider_CP1501_Prmt_SingleClaim;
        } else if (equalsIgnoreCase(tag, 'CommercialProvider_CP1501_Prmt_MoreClaims')){
            text = promptProperty.CommercialProvider_CP1501_Prmt_MoreClaims;
        } else if (equalsIgnoreCase(tag, 'CommercialProvider_CP1513_Prmt_Liability')){
            text = promptProperty.CommercialProvider_CP1513_Prmt_Liability;
        } else if (equalsIgnoreCase(tag, 'CommercialProvider_CP1513_Prmt_LiabAvailable')){
            text = promptProperty.CommercialProvider_CP1513_Prmt_LiabAvailable;
        } else if (equalsIgnoreCase(tag, 'CommercialProvider_CP1513_Prmt_ClaimAmountAvailable')){
            text = promptProperty.CommercialProvider_CP1513_Prmt_ClaimAmountAvailable;
        } else if (equalsIgnoreCase(tag, 'CommercialProvider_CP1513_Prmt_NotLiabAvailable')){
            text = promptProperty.CommercialProvider_CP1513_Prmt_NotLiabAvailable;
        } else if (equalsIgnoreCase(tag, 'CommercialProvider_CP1513_Prmt_ClaimPaid')){
            text = promptProperty.CommercialProvider_CP1513_Prmt_ClaimPaid;
        } else if (equalsIgnoreCase(tag, 'CommercialProvider_CP1513_Prmt_ClaimNotPaid')){
            text = promptProperty.CommercialProvider_CP1513_Prmt_ClaimNotPaid;
        } else if (equalsIgnoreCase(tag, 'CommercialProvider_CP1514_Prmt_YesRemit')){
            text = promptProperty.CommercialProvider_CP1514_Prmt_YesRemit;
        } else if (equalsIgnoreCase(tag, 'CommercialProvider_CP1514_Prmt_NoRemit')){
            text = promptProperty.CommercialProvider_CP1514_Prmt_NoRemit;
        } else if (equalsIgnoreCase(tag, 'CommercialProvider_CP1507_Prmt_EligibilityAvality')){
            text = promptProperty.CommercialProvider_CP1507_Prmt_EligibilityAvality
        }else if (equalsIgnoreCase(tag, 'CommercialProvider_CPCollectData_Prmt_InvalidID')){
            text = promptProperty.CommercialProvider_CPCollectData_Prmt_InvalidID
        }else if (equalsIgnoreCase(tag, 'CommercialProvider_CPCollectData_Prmt_InvalidDOB')){
            text = promptProperty.CommercialProvider_CPCollectData_Prmt_InvalidDOB
        }


    } catch (e) {
        console.error(e.message);
    }
    console.log('text : ', text);
    jsonResponse.fulfillment_response.messages[0].text.text[0] = text;
    return jsonResponse;

}

function equalsIgnoreCase(tag, key) {
    return tag.toLowerCase() === key.toLowerCase();
}

module.exports = { CP1500_Prompts };