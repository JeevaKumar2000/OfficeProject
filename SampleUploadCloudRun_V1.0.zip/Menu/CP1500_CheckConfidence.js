/**
 * 
 * @param {Request} request 
 * @param {object} promptProperty 
 * @returns 
 */
const fulfillment = require('../utils/utils.js')

async function CP1500_CheckConfidence(request) {
    let text = '';
    let confidenceLevel = 'low';
    let parameters = {};
    let jsonResponse = {};
    jsonResponse.sessionInfo = request.body.sessionInfo;
    let fulfillment_response = fulfillment.fulfillment_response();
    jsonResponse.fulfillment_response = fulfillment_response;

    try {
        if ('parameters' in (request.body.sessionInfo)) {
            parameters = request.body.sessionInfo.parameters;
        }
        //Tag Name: CorporateServices_PCS3000_CheckConfidence 
        if ('intentInfo' in request.body && 'confidence' in request.body.intentInfo) {
            confidence = request.body.intentInfo.confidence;
            console.info('Confidence Score:', confidence);
            // Set confidence level based on score
            confidenceLevel = confidence >= 0.500 ? 'high' : 'low';
            //Hardcode
            //confidenceLevel = 'low';
            //Hardcode
        }
        
        jsonResponse.sessionInfo.parameters.confidenceLevel = confidenceLevel;
        console.info('confidenceLevel value ---> ' , confidenceLevel);
    } catch (e) {
        console.error(e.message);
    }
    console.log('text : ', text);
    jsonResponse.fulfillment_response.messages[0].text.text[0] = text;
    //console.log('jsonResponse : ',jsonResponse);
    return jsonResponse;
};
module.exports = { CP1500_CheckConfidence };