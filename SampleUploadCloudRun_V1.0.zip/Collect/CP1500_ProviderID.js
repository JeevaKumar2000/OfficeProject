/**
 * 
 * @param {Request} request 
 * @param {object} promptProperty 
 * @returns 
 */
const fulfillment = require('../utils/utils.js')

async function CP1500_ProviderID(request, promptProperty) {
    let text = '';
    let parameters = {};
    let jsonResponse = {};
    jsonResponse.sessionInfo = request.body.sessionInfo;
    let fulfillment_response = fulfillment.fulfillment_response();
    jsonResponse.fulfillment_response = fulfillment_response;

    try {
        if ('parameters' in (request.body.sessionInfo)) {
            parameters = request.body.sessionInfo.parameters;
        }
        //console.log('BCBSTCollect_RetryCounter value : ', parameters.collectRetryCount);
        let currentPage = request.body.pageInfo.currentPage;
        let lastIndex = currentPage.lastIndexOf('/');
        let endSessionPage = currentPage.substring(0, lastIndex) + '/END_SESSION';
        switch(parameters.collectRetryCount){
            case '0':
                text = promptProperty.CommercialProvider_CP1501_Collect_ProviderID;
                jsonResponse.sessionInfo.parameters.collectRetryCount = '1';
                break;
            case '1':
                text = promptProperty.CommercialProvider_CP1500_Prmt_CommonRetry1 + ' ' + promptProperty.CommercialProvider_CP1501_Collect_NINM1_ProviderID;
                jsonResponse.sessionInfo.parameters.collectRetryCount = '2';
                break;
            case '2':
                text = promptProperty.CommercialProvider_CP1500_Prmt_CommonRetry2 + ' ' + promptProperty.CommercialProvider_CP1501_Collect_NINM2_ProviderID;
                jsonResponse.sessionInfo.parameters.collectRetryCount = '3';
                break;
            default:
                jsonResponse.sessionInfo.parameters.callerGoal = 'max_attempt';
                jsonResponse.targetPage = endSessionPage;
        }
    } catch (e) {
        console.error(e.message);
    }
    console.log('text : ', text);
    jsonResponse.fulfillment_response.messages[0].text.text[0] = text;
    return jsonResponse;
}
module.exports = { CP1500_ProviderID };