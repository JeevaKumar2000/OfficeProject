//Menu require things 
const { CP1500_MainMenu } = require('./Menu/CP1500_MainMenu.js');
const { CP1500_CheckConfidence } = require('./Menu/CP1500_CheckConfidence.js');
const { CP1500_ConfirmationMenu } = require('./Menu/CP1500_ConfirmationMenu.js');
const { CP1500_IntentConfirmMenu } =  require('./Menu/CP1500_IntentConfirmMenu.js');
const { CP1500_PriorAuthMenu } = require('./Menu/CP1500_PriorAuthMenu.js');
const { CP1500_MedicationMenu } = require('./Menu/CP1500_MedicationMenu.js');
const { CP1500_PriorAuthBehavioralHealthMenu } = require('./Menu/CP1500_PriorAuthBehavioralHealthMenu.js');
const { CP1500_BehavioralHealthMenu } = require('./Menu/CP1500_BehavioralHealthMenu.js');
const { CP1500_CaseManagementMenu } = require('./Menu/CP1500_CaseManagementMenu.js');
const { CP1500_MedicalMenu } = require('./Menu/CP1500_MedicalMenu.js');
const { CP1500_DentalMenu } = require('./Menu/CP1500_DentalMenu.js');
const { CP1500_AuthorizationMenu } = require('./Menu/CP1500_AuthorizationMenu.js');
const { CP1500_ConfirmProviderMenu } = require('./Menu/CP1500_ConfirmProviderMenu.js');
const { CP1500_MedicalMenuChange } = require('./Menu/CP1500_MedicalMenuChange.js');
const { CP1500_StatusChangeMenu } = require('./Menu/CP1500_StatusChangeMenu.js');
const { CP1500_ConfirmProviderNameMenu } = require('./Menu/CP1500_ConfirmProviderNameMenu.js');
const { CP1500_ChangeScenarioMenu } = require('./Menu/CP1500_ChangeScenarioMenu.js');
//Collect require things
const { CP1500_BCBSTFacilityID } = require('./Collect/CP1500_BCBSTFacilityID.js');
const { CP1500_ReferenceNumber } = require("./Collect/CP1500_ReferenceNumber.js");
const { CP1500_DateOfService } = require('./Collect/CP1500_DateOfService.js');
const { CP1500_MemberDateOfBirth } = require('./Collect/CP1500_MemberDateOfBirth.js');
const { CP1500_ProviderID } = require('./Collect/CP1500_ProviderID.js');
const { CP1500_ClaimCharge } = require('./Collect/CP1500_ClaimCharge.js');
const { CP1500_CollectQueries } = require('./Collect/CP1500_CollectQueries.js');
//Implementaion require things
const { CP1500_ReferenceNumberDA } = require('./Implementation/CP1500_ReferenceNumberDA.js');
const { CP1500_MemberEligibilityDA } = require('./Implementation/CP1500_MemberEligibilityDA.js');
const { CP1500_ProviderIDDA } = require('./Implementation/CP1500_ProviderIDDA.js');
const { CP1500_MemberDOBDA } = require('./Implementation/CP1500_MemberDOBDA.js');
const { CP1500_ClaimStatusSummaryDA } = require('./Implementation/CP1500_ClaimStatusSummaryDA.js');
const { CP1500_ClaimStatusDetailsDA } = require('./Implementation/CP1500_ClaimStatusDetailsDA.js');
//Prompt require things
const { CP1500_Prompts } = require('./Prompt/CP1500_Prompts.js');
const { CP1500_EligibilityPrompts } = require('./Prompt/CP1500_EligibilityPrompts.js');
// Others
const utils = require('./utils/utils.js');
const functions = require('@google-cloud/functions-framework');
require('dotenv').config();
const fileName = process.env.fileName;


functions.http('CommercialProviderWebhook', async(request, response) => {
    
    let promptList = null;
    let jsonResponse = {};
    let text = "";
    jsonResponse.sessionInfo = request.body.sessionInfo;
    let fulfillment_response = utils.fulfillment_response();
    jsonResponse.fulfillment_response = fulfillment_response;
    let tag = request.body.fulfillmentInfo.tag;
    console.info('---------------------------');
    console.info('Tag : ', tag);
    appName = tag.split("_")[0].trim();
    
    
    // Load prompt list if not already loaded
    if (!promptList) {
        promptList = utils.downloadPromptFile(fileName);
        console.log(" ******* Retrieved PromptList ********* ");
    }

    // Menu's method call Tag start
    if (utils.equalsIgnoreCase(tag,'CommercialProvider_CP1504_MainMenu')) {
        console.info(' CommercialProvider Tag Started ');
        jsonResponse = await CP1500_MainMenu(request, promptList);
    }else if(utils.equalsIgnoreCase(tag,'CommercialProvider_CheckConfidence')) { // Check Confidence level 
        jsonResponse = await CP1500_CheckConfidence(request);
    }else if(utils.equalsIgnoreCase(tag,'CommercialProvider_CP1500_SubMenu_ConfirmationMenu1') || utils.equalsIgnoreCase(tag,'CommercialProvider_CP1511_SubMenu_ConfirmationMenu2')) {  // Menu confirmation
        jsonResponse = await CP1500_ConfirmationMenu(request, promptList, tag);
    }else if(utils.equalsIgnoreCase(tag,'CommercialProvider_ConfirmationNo')){           // Confirmation No 
        jsonResponse = await CP1500_ConfirmationMenu(request, promptList, tag);
    }else if(utils.equalsIgnoreCase(tag,'CommercialProvider_CP1504_SubMenu_IntentMenu')){
        jsonResponse = await CP1500_IntentConfirmMenu(request, promptList);
    }else if(utils.equalsIgnoreCase(tag,'CommercialProvider_CP1509_SubMenu_PriorAuthMenu')){      // Prior Auth Menu
        jsonResponse = await CP1500_PriorAuthMenu(request, promptList);
    }else if(utils.equalsIgnoreCase(tag,'CommercialProvider_CP1519_SubMenu_MedicationMenu')){    // Medication Menu
        jsonResponse = await CP1500_MedicationMenu(request, promptList);
    }else if(utils.equalsIgnoreCase(tag,'CommercialProvider_CP1520_SubMenu_PABehavioralHealthMenu')){    // Prior Auth BehavioralHealth Menu
        jsonResponse = await CP1500_PriorAuthBehavioralHealthMenu(request, promptList);
    }else if(utils.equalsIgnoreCase(tag,'CommercialProvider_CP1521_SubMenu_BehavioralHealthMenu')){    // BehavioralHealth Menu
        jsonResponse = await CP1500_BehavioralHealthMenu(request, promptList);
    }else if(utils.equalsIgnoreCase(tag,'CommercialProvider_CP1510_SubMenu_CaseManagementMenu')){    // CaseManagement  Menu
        jsonResponse = await CP1500_CaseManagementMenu(request, promptList);
    }else if(utils.equalsIgnoreCase(tag,'CommercialProvider_CP1505_SubMenu_MedicalMenu')){    // Medical Menu
        jsonResponse = await CP1500_MedicalMenu(request, promptList);
    }else if(utils.equalsIgnoreCase(tag,'CommercialProvider_CP1508_SubMenu_DentalMenu')){    // Dental Menu
        jsonResponse = await CP1500_DentalMenu(request, promptList);
    }else if(utils.equalsIgnoreCase(tag,'CommercialProvider_CP1515_SubMenu_AuthorizationMenu')){    // Authorization Menu
        jsonResponse = await CP1500_AuthorizationMenu(request, promptList);
    }else if(utils.equalsIgnoreCase(tag,'CommercialProvider_CP1515_SubMenu_ConfirmProviderID')){    // ConfirmProvider Menu
        jsonResponse = await CP1500_ConfirmProviderMenu(request, promptList);
    }else if(utils.equalsIgnoreCase(tag,'CommercialProvider_CP1507_SubMenu_MedicalMenuChange')){    // Authorization Menu
        jsonResponse = await CP1500_MedicalMenuChange(request, promptList);
    }else if(utils.equalsIgnoreCase(tag,'CommercialProvider_CP1512_SubMenu_StatusChangeMenu')){    // CaseManagement  Menu
        jsonResponse = await CP1500_StatusChangeMenu(request, promptList);
    }else if(utils.equalsIgnoreCase(tag,'CommercialProvider_CP1523_SubMenu_ConfirmProviderNameMenu')){    // CaseManagement  Menu
        jsonResponse = await CP1500_ConfirmProviderNameMenu(request, promptList);
    }else if(utils.equalsIgnoreCase(tag,'CommercialProvider_CP1523_SubMenu_ConfirmProviderNameMenu')){    // CaseManagement  Menu
        jsonResponse = await CP1500_ChangeScenarioMenu(request, promptList);
    }
    // Menu's method call Tag end
    // Prompt's method call Tag start
    else if(utils.equalsIgnoreCase(tag,'CommercialProvider_CP1500_Prmt_Acknowledgement') || utils.equalsIgnoreCase(tag,'CommercialProvider_CP1505_Prmt_Avality') || utils.equalsIgnoreCase(tag,'CommercialProvider_CP1507_Prmt_EligibilityAvality') || utils.equalsIgnoreCase(tag,'CommercialProvider_CP1507_Prmt_NotMemberEligible') || utils.equalsIgnoreCase(tag,'CommercialProvider_CP1507_Prmt_PlanDesc') || utils.equalsIgnoreCase(tag,'CommercialProvider_CP1507_Prmt_CoPayReturn') || utils.equalsIgnoreCase(tag,'CommercialProvider_CP1511_Prmt_ClaimNotify') || utils.equalsIgnoreCase(tag,'CommercialProvider_CP1512_Prmt_LookupResponse') || utils.equalsIgnoreCase(tag,'CommercialProvider_CP1512_Prmt_LookupResponseLT') || utils.equalsIgnoreCase(tag,'CommercialProvider_CP1512_Prmt_LookupResponseGT') || utils.equalsIgnoreCase(tag,'CommercialProvider_CP1523_Prmt_ClaimLookup')){       // PP --> Play prompt Acknowledgement
        jsonResponse = await CP1500_Prompts(request, promptList, tag);
    }else if(utils.equalsIgnoreCase(tag,'CommercialProvider_CP1500_Prmt_EligibilityPrompts')){
        jsonResponse = await CP1500_EligibilityPrompts(request, promptList, tag);
    }else if(utils.equalsIgnoreCase(tag,'CommercialProvider_CP1501_Prmt_SingleClaim') || utils.equalsIgnoreCase(tag,'CommercialProvider_CP1501_Prmt_MoreClaims') || utils.equalsIgnoreCase(tag,'CommercialProvider_CP1513_Prmt_Liability') || utils.equalsIgnoreCase(tag,'CommercialProvider_CP1513_Prmt_ClaimNoAvailable') || utils.equalsIgnoreCase(tag,'CommercialProvider_CP1513_Prmt_ClaimAmountAvailable') || utils.equalsIgnoreCase(tag,'CommercialProvider_CP1513_Prmt_LiabAvailable') || utils.equalsIgnoreCase(tag,'CommercialProvider_CP1513_Prmt_NotLiabAvailable') || utils.equalsIgnoreCase(tag,'CommercialProvider_CP1513_Prmt_ClaimPaid') || utils.equalsIgnoreCase(tag,'CommercialProvider_CP1513_Prmt_ClaimNotPaid') || utils.equalsIgnoreCase(tag,'CommercialProvider_CP1514_Prmt_YesRemit') || utils.equalsIgnoreCase(tag,'CommercialProvider_CP1514_Prmt_NoRemit')){ //|| equalsIgnoreCase(tag,'CommercialProvider_CP1501_Prmt_MoreClaims')      
        jsonResponse = await CP1500_Prompts(request, promptList, tag);
    }else if(utils.equalsIgnoreCase(tag,'CommercialProvider_CPCollectData_Prmt_InvalidID') || utils.equalsIgnoreCase(tag,'CommercialProvider_CPCollectData_Prmt_InvalidDOB')){ //|| equalsIgnoreCase(tag,'CommercialProvider_CP1501_Prmt_MoreClaims')      
        jsonResponse = await CP1500_Prompts(request, promptList, tag);
    }
    // Prompt's method call Tag end
    // Collect's method call Tag start
    else if(utils.equalsIgnoreCase(tag,'CommercialProvider_CP1515_Collect_BCBSTFacilityID')){    // BCBST facility ID collect
        jsonResponse = await CP1500_BCBSTFacilityID(request, promptList);
    }else if(utils.equalsIgnoreCase(tag,'CommercialProvider_CP1516_Collect_ReferenceNumber')){    // Reference number collect
        jsonResponse = await CP1500_ReferenceNumber(request, promptList);
    }else if(utils.equalsIgnoreCase(tag,'CommercialProvider_CP1506_Collect_DateOfService')){    // Date of service collect
        jsonResponse = await CP1500_DateOfService(request, promptList);
    }else if(utils.equalsIgnoreCase(tag,'CommercialProvider_CP1503_Collect_MemberDOB')){    // Date of service collect
        jsonResponse = await CP1500_MemberDateOfBirth(request, promptList);
    }else if(utils.equalsIgnoreCase(tag,'CommercialProvider_CP1501_Collect_ProviderID')){    // Authorization Menu
        jsonResponse = await CP1500_ProviderID(request, promptList);
    }else if(utils.equalsIgnoreCase(tag,'CommercialProvider_CP1522_Collect_ClaimCharge')){    // Authorization Menu
        jsonResponse = await CP1500_ClaimCharge(request, filteredData);
     }else if(utils.equalsIgnoreCase(tag,'CommercialProvider_CP1518_Collect_CallerGoal')){    // Authorization Menu
        jsonResponse = await CP1500_CollectQueries(request, filteredData);
     }
    // Collect's method call Tag end
    // Implement's method call Tag start
    else if(utils.equalsIgnoreCase(tag,'CommercialProvider_CP1516_ReferenceNumberDA')){    // Reference number DA
        jsonResponse = await CP1500_ReferenceNumberDA(request);
    }else if(utils.equalsIgnoreCase(tag,'CommercialProvider_CP1516_MemberEligibilityDA')){    // Reference number DA
        jsonResponse = await CP1500_MemberEligibilityDA(request);
    }else if(utils.equalsIgnoreCase(tag,'CommercialProvider_CP1516_ProviderIDDA')){    // Provider ID DA
        jsonResponse = await CP1500_ProviderIDDA(request);
    }else if(utils.equalsIgnoreCase(tag,'CommercialProvider_CP1503_MemberDOBDA')){    // Member DOB DA
        jsonResponse = await CP1500_MemberDOBDA(request);
    }else if(utils.equalsIgnoreCase(tag,'CommercialProvider_CP1522_ClaimStatusSummaryDA')){    // Claims Summary DA
        jsonResponse = await CP1500_ClaimStatusSummaryDA(request);
    }else if(utils.equalsIgnoreCase(tag,'CommercialProvider_CP1523_ClaimStatusDetailsDA')){    // Claims Summary DA
        jsonResponse = await CP1500_ClaimStatusDetailsDA(request);
    }else{
        let text = "";
        console.error(`There are no fulfillment responses defined for "${tag}" tag`);     
        jsonResponse.fulfillment_response.messages[0].text.text[0] = text;
    }
    console.info('---------------------------');
    response.send(jsonResponse);
	
});

