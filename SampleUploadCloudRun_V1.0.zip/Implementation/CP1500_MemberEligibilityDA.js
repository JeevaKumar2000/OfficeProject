/**
 * 
 * @param {Request} request 
 * @param {object} promptProperty 
 * @returns 
 */
const fulfillment = require('../utils/utils.js')

async function CP1500_MemberEligibilityDA(request) {
    let text = '';
    let parameters = {};
    let jsonResponse = {};
    jsonResponse.sessionInfo = request.body.sessionInfo;
    let fulfillment_response = fulfillment.fulfillment_response();
    jsonResponse.fulfillment_response = fulfillment_response;

    try {

        if ('parameters' in (request.body.sessionInfo)) {
            parameters = request.body.sessionInfo.parameters;
        }
        const result = await fetch(`https://qnw180rd-9000.inc1.devtunnels.ms/api/post/memberValidation?subscriberId=${parameters.subscriberId}&dateOfBirth=${parameters.dateOfBirth}&dateOfService=${parameters.dateOfService}`, {
            signal: AbortSignal.timeout(6000)
        });

        //console.log('Api result is :', result);

        if (!result.ok) {
            // Handle HTTP errors
            console.error(`HTTP error! Status: ${result.status}`);
            throw new Error(`API responded with status ${result.status}`);
        }

        const contentType = result.headers.get('content-type');
        if (!contentType || !contentType.includes('application/json')) {
            console.error('Invalid content type:', contentType);
            throw new Error('Server did not return JSON');
        }

        const data = await result.json();

        if (result.status === 200) {
            if (data.subscriberId === '111111111111') {
                console.log('Member eligibility InValid Response is :', data.properties);
                jsonResponse.sessionInfo.parameters.status = 'Success';
                jsonResponse.sessionInfo.parameters.response = 'InValid';
            } else {
                console.log('Member eligibility Valid Response is :', data.properties);
                jsonResponse.sessionInfo.parameters.memberEligibilityResponse = data.properties;
                jsonResponse.sessionInfo.parameters.status = 'Success';
                jsonResponse.sessionInfo.parameters.response = 'Valid';
            }
        } else {
            jsonResponse.sessionInfo.parameters.status = 'Failure';
        }

        console.log('sessionInfo.parameters.status is :', jsonResponse.sessionInfo.parameters.status );
        console.log('sessionInfo.parameters.response is :', jsonResponse.sessionInfo.parameters.response );

    } catch (e) {
        console.error(e.message);
    }
    return jsonResponse;
}
module.exports = { CP1500_MemberEligibilityDA };