/**
 * 
 * @param {Request} request 
 * @param {object} promptProperty 
 * @returns 
 */
const fulfillment = require('../utils/utils.js')

async function CP1500_ProviderIDDA(request) {
    let text = '';
    let parameters = {};
    let jsonResponse = {};
    jsonResponse.sessionInfo = request.body.sessionInfo;
    let fulfillment_response = fulfillment.fulfillment_response();
    jsonResponse.fulfillment_response = fulfillment_response;

    try {

        if ('parameters' in (request.body.sessionInfo)) {
            parameters = request.body.sessionInfo.parameters;
        }

        const result = await fetch(`https://qnw180rd-9000.inc1.devtunnels.ms/api/post/providerId?providerId=${parameters.collectValue}`, {
            signal: AbortSignal.timeout(6000)
        });

        console.log('Api over all result is :', result);

        if (!result.ok) {
            // Handle HTTP errors
            console.error(`HTTP error! Status: ${result.status}`);
            throw new Error(`API responded with status ${result.status}`);
        }

        const contentType = result.headers.get('content-type');
        if (!contentType || !contentType.includes('application/json')) {
            console.error('Invalid content type:', contentType);
            throw new Error('Server did not return JSON');
        }

        const data = await result.json();
        //console.log('Api data is : ', JSON.stringify(data));

        if (result.status === 200) {
            console.log('Status code is :', result.status);
            console.log('API Status is : ', data.properties.validProv);

            console.log('validProvider is  : ', data.properties.validProv);
            if (data.properties.validProv === true) {
                jsonResponse.sessionInfo.parameters.status = data.properties.validProv;
            } else {
                jsonResponse.sessionInfo.parameters.status = data.properties.validProv;
            }

        } else {
            console.log('Status code is :', result.status);
        }

        console.log('API validProv is :', jsonResponse.sessionInfo.parameters.status);


    } catch (e) {
        console.error(e.message);
    }
    return jsonResponse;
}
module.exports = { CP1500_ProviderIDDA };